#include "Menu.h"

int main()
{
    Menu start_menu;
    start_menu.mainScreen();
}  