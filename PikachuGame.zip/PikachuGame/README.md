Copy this statement and paste on the terminal to build the file

g++ main.cpp menu.h Game.h Controller.h BoardView.h Point.h Controller.cpp Game.cpp BoardView.cpp Point.cpp menu.cpp -lwinmm